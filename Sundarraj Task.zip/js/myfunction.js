$('.owl-carousel').owlCarousel({
    margin: 10,
    dots: false,
    navText: ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"],
    nav: true,
    loop:true,
    autoplaySpeed:1000,
    lazyLoad:true,
    autoplay:true,
    
    responsive: {
        0: {
            nav: true,
            items: 1
        },
        600: {
            nav: true,
            items: 3
        },
        1000: {
            nav: true,
            items: 5
        }
    }
});

//form valitation

$('.sendbtn').click(function(){
    var pattern = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i
    var fname = $('.fname').val();
    var lname = $('.lname').val();
    var email = $('.email').val();
    var message = $('.message').val();

    if(fname.length > 0){
        if(lname.length > 0){
            if(email.length > 0){
                if(!validateEmail(email)){
                    $('.email').val("");
                    $('.email').attr("placeholder", "Not a valid e-mail address");
                }else{
                    if(message.length > 0){
                        $('.fname').val("");
                        $('.lname').val("");
                        $('.email').val("");
                        $('.message').val("");
                        $('.fname').attr("placeholder", "");
                        $('.lname').attr("placeholder", "");
                        $('.email').attr("placeholder", "");
                        $('.message').attr("placeholder", "");
                        swal('Message', 'Message successfully sent', 'success');

                    }else{
                        $('.message').attr("placeholder", "Enter Min One Letters");
                    }
                }
            }else{
                $('.email').attr("placeholder", "Enter Min One Letters");
            }
        }else{
            $('.lname').attr("placeholder", "Enter Min One Letters");
        }
    }else{
        $('.fname').attr("placeholder", "Enter Min One Letters");
    }
});

function validateEmail($email) {
    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    return emailReg.test( $email );
}
